<?php 
ob_start();
 $to = "info@khfinancial.ca";
         $subject = "Client Message";
         $contact= $_GET["contact_name"];
         $email= $_GET["contact_email"];
         $phone= $_GET["contact_phone"];
         $sub= $_GET["contact_subject"];
         $cn_message= $_GET["contact_message"];
         $message = "<h1>KHFinancial COntact Form</h1></br>";
         $message .= "<p>Name: $contact</p>";
         $message .= "<p>Email: $email</p>";
         $message .= "<p>Phone: $phone</p>";
         $message .= "<p>Subject Chosen: $sub</p>";
         $message .= "<p>Message: $cn_message</p>";
         
         
         
         $header = "From: KHFinancial <info@khfinancial.ca> \r\n";
         $header .= "MIME-Version: 1.0\r\n";
         $header .= "Content-type: text/html\r\n";
         
         $retval = mail ($to,$subject,$message,$header);
       
         if( $retval = true ) { 
         echo '<script>alert("Your message has been sent. We will contact you soon if you do not hear from us the message may not have sent.");window.location.replace("https://khfinancial.ca/contact.html");</script>'
         ;} else {
            echo '<script>alert("Sorry, Message could not be delivered. Please try again later Thank you.");window.location.replace("https://khfinancial.ca/contact.html");</script>'
          
         ;}


?>